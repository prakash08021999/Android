package com.example.hempra.webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=findViewById(R.id.w1);
		//Enable Java Script of webView
        webView.getSettings().setJavaScriptEnabled(true);
		//To Create Instance of web Client 
        webviewclient webviewclient=new webviewclient(this);
        webView.setWebViewClient(webviewclient);
		//Load The Html  page of the Given Url 
        webView.loadUrl("https://www.google.com");

    }
	//For Back Click Of Button
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if ((keyCode==KeyEvent.KEYCODE_BACK)&& (webView.canGoBack())){
            this.webView.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
}
